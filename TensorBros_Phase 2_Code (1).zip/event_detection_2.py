
# coding: utf-8

# In[35]:


import banpei
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import time
import datetime as dt

from scipy.signal import find_peaks, peak_widths, peak_prominences

import random

from sklearn.preprocessing import MinMaxScaler

import warnings
warnings.filterwarnings('ignore')


# # Read files

# In[36]:


df = pd.read_csv('../Data/book_events_total_view_2017-01-03.csv')


# In[37]:


df = df.drop(columns='Unnamed: 0')


# # Considering only three sectors for initial analysis

# In[38]:


sectors = ['Health Care', 'Financials', 'Information Technology']


# In[39]:


sector_dfs = [df.loc[df['sector'] == x] for x in sectors]


# In[40]:


len(sector_dfs)


# In[41]:


sector_dfs[0].head()


# In[42]:


df = df.sort_values(by='timestamp', axis=0)


# In[43]:


df["sector"].value_counts().plot(kind='bar')
plt.show()


# # Considering only one company per sector for initial analysis

# In[44]:


sector_dfs[0]['ticker'].value_counts().reset_index()['index'].iloc[0]


# In[45]:


#sector_company_dfs = [x.loc[x['ticker'] == x['ticker'].unique()[0]] for x in sector_dfs]


# In[46]:


sector_company_dfs = [x.loc[x['ticker'] == x['ticker'].value_counts().reset_index()['index'].iloc[0]] for x in sector_dfs]


# In[47]:


len(sector_company_dfs)


# In[48]:


sector_company_dfs[0]['ticker'].unique()


# In[49]:


sector_company_dfs[1]['ticker'].unique()


# In[50]:


sector_company_dfs[2]['ticker'].unique()


# In[51]:


len(sector_company_dfs[0])


# In[52]:


len(sector_company_dfs[1])


# In[53]:


len(sector_company_dfs[2])


# # Changepoint detection

# In[54]:


window_size = 100


# In[55]:


def identify_changepoints(signal):
    sst = banpei.SST(w = window_size)
    return sst.detect(signal, is_lanczos=True)


# In[56]:


price_changepoints_dfs = [identify_changepoints(np.array(x['price'])) for x in sector_company_dfs]


# In[57]:


len(price_changepoints_dfs)


# In[58]:


len(price_changepoints_dfs[0])


# In[59]:


len(price_changepoints_dfs[1])


# In[60]:


len(price_changepoints_dfs[2])


# In[61]:


def plot_xy(x,y):
    fig_size = plt.rcParams["figure.figsize"]
    fig_size[0] = 100
    fig_size[1] = 10
    plt.rcParams["figure.figsize"] = fig_size
    plt.plot(x, y)
    plt.show()


# In[62]:


for i in range(len(price_changepoints_dfs)):
    plot_xy(sector_company_dfs[i]['timestamp'], sector_company_dfs[i]['price'])
    plot_xy(sector_company_dfs[i]['timestamp'], price_changepoints_dfs[i])


# In[63]:


def slope(x1, y1, x2, y2):
    m = (y2-y1)/(x2-x1)
    return m


# In[64]:


sector_events_dfs = []
changepoint_peak_indices = []

for i in range(0, len(sectors)):
    
    sector_events_df = pd.DataFrame()
    
    changepoint_std = np.std(price_changepoints_dfs[i])
    peaks, properties = find_peaks(price_changepoints_dfs[i], height = changepoint_std * 0.5)
    widths_peak = peak_widths(price_changepoints_dfs[i], peaks, rel_height=0.0)
    width_lowest_contour = peak_widths(price_changepoints_dfs[i], peaks, rel_height=1.0)
    
    changepoint_peak_indices.append(peaks)
    
    #print(len(peaks)/len(price_changepoints_dfs[i]))
    
    for j in range(len(peaks)):
        height = properties['peak_heights'][j]
        width = width_lowest_contour[0][j]
        distance = 0
        if j > 0:
            distance = widths_peak[2][j] - widths_peak[2][j-1]
        left_slope = slope(width_lowest_contour[2][j], width_lowest_contour[1][j],widths_peak[2][j], properties['peak_heights'][j])
        right_slope = slope(widths_peak[2][j], properties['peak_heights'][j],width_lowest_contour[3][j], width_lowest_contour[1][j])
        
        sector_events_df = pd.concat([sector_events_df,
                                     pd.DataFrame(
                                         data={
                                             'height': height,
                                             'width': width,
                                             'distance': distance,
                                             'left_slope': left_slope,
                                             'right_slope': right_slope
                                         },index=[0]
                                     )
                                     ])
    
    sector_events_df['event_sector'] = sectors[i]
    
    #print(sector_events_df.head())
    
    #print(len(sector_events_df['height']))
    #print(sector_events_df['height'].unique())
    #print(MinMaxScaler().fit_transform(sector_events_df.as_matrix(columns=['height'])))
    
    
    sector_events_df['height'] = MinMaxScaler().fit_transform(sector_events_df.as_matrix(columns = ['height']))
    sector_events_df['width'] = MinMaxScaler().fit_transform(sector_events_df.as_matrix(columns = ['width']))
    sector_events_df['distance'] = MinMaxScaler().fit_transform(sector_events_df.as_matrix(columns = ['distance']))
    sector_events_df['left_slope'] = MinMaxScaler().fit_transform(sector_events_df.as_matrix(columns = ['left_slope']))
    sector_events_df['right_slope'] = MinMaxScaler().fit_transform(sector_events_df.as_matrix(columns = ['right_slope']))
    
    
    print(len(sector_events_df) == len(peaks))
    
    sector_events_dfs.append(sector_events_df)
        


# In[65]:


len(sector_events_dfs) == len(changepoint_peak_indices)


# ### peak_index should be changed with timestamp to improve the accuracy of average prices

# In[66]:


# for e in range(0, len(sectors)):
#     for t in range(0, len(sectors)):
#         if e != t:
#             sector_events_dfs[e]['target_sector'] = sectors[t]
            
#             average_window_size = int(0.05 * len(sector_company_dfs[t]))
#             offset = int(0.25 * average_window_size)
#             average_prices_during_event = []
            
#             for peak_index in range(0, len(changepoint_peak_indices[e])):
#                 average_window_start_index = max(
#                     min(changepoint_peak_indices[e][peak_index]-offset,changepoint_peak_indices[e][peak_index]),
#                     0)
#                 average_prices_during_event.append(
#                     np.mean(
#                         sector_company_dfs[t]['price'][average_window_start_index
#                                                        :
#                                                        average_window_start_index + average_window_size]))
                    
                
# #                 average_prices_during_event.append(
# #                     np.mean(
# #                         sector_company_dfs[t]['price'][changepoint_peak_indices[e][peak_index]-offset
# #                                                        :
# #                                                        changepoint_peak_indices[e][peak_index]+average_window_size-offset]))
            
#             sector_events_dfs[e]['target_sector_average_price'] = average_prices_during_event
            
#             # if no prices are observed during event time
#             # for prediction purpose even if this is set to average it is same
#             sector_events_dfs[e]['target_sector_average_price'] = sector_events_dfs[e]['target_sector_average_price'].fillna(0)
            
#             sector_events_dfs[e]['target_sector_average_price'] = MinMaxScaler().fit_transform(sector_events_dfs[e].as_matrix(columns = ['target_sector_average_price']))
            
#             print(sector_events_dfs[e].head())
            


# In[67]:


for e in range(0, len(sectors)):
    updated_event_sector_df = pd.DataFrame()
    for t in range(0, len(sectors)):
        if e != t:
            sector2_df = sector_events_dfs[e]
            sector2_df['target_sector'] = sectors[t]
            
            # because price is caculated from original df
            average_window_size = int(0.05 * len(sector_company_dfs[t]))
            offset = int(0.25 * average_window_size)
            average_prices_during_event = []
            
            for peak_index in range(0, len(changepoint_peak_indices[e])):
                # check this could be redundant
                average_window_start_index = max(changepoint_peak_indices[e][peak_index]-offset, 0)
                average_window_end_index = min(len(sector_company_dfs[t]['price'])-1, average_window_start_index + average_window_size)
                
                average_prices_during_event.append(
                    np.mean(
                        sector_company_dfs[t]['price'][average_window_start_index
                                                       :
                                                       average_window_end_index]))
                    
                
#                 average_prices_during_event.append(
#                     np.mean(
#                         sector_company_dfs[t]['price'][changepoint_peak_indices[e][peak_index]-offset
#                                                        :
#                                                        changepoint_peak_indices[e][peak_index]+average_window_size-offset]))
            
            sector2_df['target_sector_average_price'] = average_prices_during_event
            
            # if no prices are observed during event time
            # for prediction purpose even if this is set to average it is same
            sector2_df['target_sector_average_price'] = sector2_df['target_sector_average_price'].fillna(np.mean(sector_company_dfs[t]['price']))
            
            sector2_df['target_sector_average_price'] = MinMaxScaler().fit_transform(sector2_df.as_matrix(columns = ['target_sector_average_price']))
            
            updated_event_sector_df = pd.concat([updated_event_sector_df, sector2_df])
            
            #print(sector_events_dfs[e].head())
    
    sector_events_dfs[e] = updated_event_sector_df
            


# In[68]:


for i in range(0, len(sectors)):
    sector_events_dfs[i].to_csv('{0}.csv'.format(sectors[i]), index=False)


# In[71]:


len(sector_events_dfs[0])+len(sector_events_dfs[1])+len(sector_events_dfs[2])

