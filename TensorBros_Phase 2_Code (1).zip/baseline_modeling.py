
# coding: utf-8

# In[1]:


import banpei
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import time
import datetime as dt

import random

from sklearn.preprocessing import MinMaxScaler

import warnings
warnings.filterwarnings('ignore')


from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error


# In[2]:


healthcare = pd.read_csv('Health Care.csv')


# In[3]:


healthcare.head()


# In[4]:


healthcare_financials = healthcare.loc[healthcare['target_sector'] == 'Financials']


# In[5]:


healthcare_financials.head()


# In[6]:


healthcare_financials.columns


# In[7]:


x_columns = ['height', 'width', 'distance', 'left_slope', 'right_slope']


# In[8]:


y = ['target_sector_average_price']


# # testing on healthcare vs financials

# In[9]:


X_train, X_test, y_train, y_test = train_test_split(healthcare_financials[x_columns], healthcare_financials[y], test_size=0.2, random_state=42)


# In[10]:


len(X_train) / len(healthcare_financials)


# In[11]:


linreg = LinearRegression().fit(X_train, y_train)


# In[12]:


linreg.score(X_train, y_train)


# In[13]:


linreg.coef_


# In[14]:


y_hat = linreg.predict(X_test)


# In[15]:


mean_squared_error(y_test, y_hat)


# # For all sectors

# In[22]:


x_columns = ['height', 'width', 'distance', 'left_slope', 'right_slope']
y = ['target_sector_average_price']

mse_df = pd.DataFrame()
r2_df = pd.DataFrame()

counts = []

for sector in ['Health Care', 'Financials', 'Information Technology']:
    df = pd.read_csv('{0}.csv'.format(sector))
    
    mse_row = {'event_sector_mse':sector, sector:None}
    r2_row = {'event_sector_r2':sector, sector:None}
    
    for target_sector in df['target_sector'].unique():
        df_target = df.loc[df['target_sector'] == target_sector]
        
        X_train, X_test, y_train, y_test = train_test_split(df_target[x_columns], df_target[y], test_size=0.25, random_state=42)
        
        counts.append(["{0}-{1}".format(sector, target_sector), len(X_train), len(X_test)])

        linreg = LinearRegression().fit(X_train, y_train)
        
        r2 = linreg.score(X_train, y_train)
        
        y_hat = linreg.predict(X_test)
        
        mse = mean_squared_error(y_test, y_hat)
        
        mse_row[target_sector] = mse
        r2_row[target_sector] = r2
        
        print(linreg.coef_)
        
    
    mse_df = pd.concat([mse_df, pd.DataFrame(data=mse_row,index=[0])])
    r2_df = pd.concat([r2_df, pd.DataFrame(data=r2_row,index=[0])])


mse_df.to_csv('mse.csv',index=False)
r2_df.to_csv('r2.csv',index=False)

print(mse_df.head())
print(r2_df.head())

pd.DataFrame(data=counts, columns=['Dataset Type', 'Train Event Count', 'Test Event Count']).to_csv('counts.csv')
        


# In[23]:


linreg.summary

