#!/usr/bin/env python
# coding: utf-8

# In[1]:


import tensorflow as tf
from tensorflow.contrib import learn
import matplotlib.pyplot as plt
from sklearn.pipeline import Pipeline
from sklearn import datasets, linear_model
from sklearn.model_selection import cross_validate
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd


# In[2]:


fin_data = pd.read_csv('C:/Users/Charishma/Desktop/Financials.csv')
it_data = pd.read_csv('C:/Users/Charishma/Desktop/Information Technology.csv')
hc_data = pd.read_csv('C:/Users/Charishma/Desktop/Health Care.csv')
#fin_data.head()


# In[3]:


print(fin_data['target_sector'].unique())
print(it_data['target_sector'].unique())
print(hc_data['target_sector'].unique())


# In[4]:


fin_hc_data = fin_data.loc[fin_data['target_sector'] == 'Health Care']
fin_it_data = fin_data.loc[fin_data['target_sector'] == 'Information Technology']
hc_fin_data = hc_data.loc[hc_data['target_sector'] == 'Financials']
hc_it_data = hc_data.loc[hc_data['target_sector'] == 'Information Technology']
it_fin_data = it_data.loc[it_data['target_sector'] == 'Financials']
it_hc_data = it_data.loc[it_data['target_sector'] == 'Health Care']


# In[5]:


len(it_hc_data)


# In[23]:


#1
#financial - healthcare
#fin_data = pd.read_csv('C:/Users/Charishma/Desktop/dummy_Financials.csv')
#fin_hc_data = fin_data.loc[fin_data['target_sector'] == 'Health Care']
X = it_hc_data[['height', 'width', 'distance', 'left_slope', 'right_slope']]
Y = it_hc_data['target_sector_average_price']
X = X.values
Y = Y.values
#Test size?
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

total_len = X_train.shape[0]

# Parameters
learning_rate = 0.001
training_epochs = 150
batch_size = 10
display_step = 1
#keep_prob = 0.5
#dropout_rate = 0.9
# Network Parameters
n_hidden_1 = 100 # 1st layer number of features
n_hidden_2 = 100 # 2nd layer number of features
n_hidden_3 = 156
#n_hidden_4 = 156
n_input = X_train.shape[1]
n_classes = 1

# tf Graph input
x = tf.placeholder("float", [None, n_input], name = 'X')
y = tf.placeholder("float", [None], name = 'Y')
#keep_prob = tf.placeholder(tf.float32)

# Create model
def multilayer_perceptron(x, weights, biases):
    # Hidden layer with activation
    layer_1 = tf.add(tf.matmul(x, weights['h1']), biases['b1'])
    layer_1 = tf.nn.relu(layer_1)
    #layer_1 = tf.nn.dropout(layer_1, keep_prob)

    # Hidden layer with activation
    layer_2 = tf.add(tf.matmul(layer_1, weights['h2']), biases['b2'])
    layer_2 = tf.nn.relu(layer_2)
    #layer_2 = tf.nn.dropout(layer_2, keep_prob)

    # Hidden layer with activation
    layer_3 = tf.add(tf.matmul(layer_2, weights['h3']), biases['b3'])
    layer_3 = tf.nn.relu(layer_3)
    #layer_3 = tf.nn.dropout(layer_3, keep_prob)

#     # Hidden layer with activation
#     layer_4 = tf.add(tf.matmul(layer_3, weights['h4']), biases['b4'])
#     layer_4 = tf.nn.relu(layer_4)

    # Output layer with linear activation
    out_layer = tf.matmul(layer_3, weights['out']) + biases['out']
    return out_layer

# Store layers weight & bias
#tf.random.set_random_seed(1234)
weights = {
    'h1': tf.Variable(tf.random_normal([n_input, n_hidden_1], 0, 0.1), name = 'w1'),
    'h2': tf.Variable(tf.random_normal([n_hidden_1, n_hidden_2], 0, 0.1), name = 'w2'),
    'h3': tf.Variable(tf.random_normal([n_hidden_2, n_hidden_3], 0, 0.1), name = 'w3'),
#     'h4': tf.Variable(tf.random_normal([n_hidden_3, n_hidden_4], 0, 0.1)),
    'out': tf.Variable(tf.random_normal([n_hidden_3, n_classes], 0, 0.1), name = 'w0')
}
biases = {
    'b1': tf.Variable(tf.random_normal([n_hidden_1], 0, 0.1), name = 'w1'),
    'b2': tf.Variable(tf.random_normal([n_hidden_2], 0, 0.1), name = 'w2'),
    'b3': tf.Variable(tf.random_normal([n_hidden_3], 0, 0.1), name = 'w3'),
#     'b4': tf.Variable(tf.random_normal([n_hidden_4], 0, 0.1)),
    'out': tf.Variable(tf.random_normal([n_classes], 0, 0.1), name = 'w0')
}

# Construct model
pred = multilayer_perceptron(x, weights, biases)

# Define loss and optimizer
cost = tf.reduce_mean(tf.square(pred-y))
#l1_regularizer = tf.contrib.layers.l1_regularizer(scale=0.005, scope=None)
#regularization_penalty = tf.contrib.layers.apply_regularization(l1_regularizer, weights)
#regularized_loss = cost + regularization_penalty
#optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost)
optimizer = tf.train.GradientDescentOptimizer(learning_rate=learning_rate).minimize(cost)
saver = tf.train.Saver()

# Launch the graph
with tf.Session() as sess:
   # writer = tf.summary.FileWriter('C:/Users/Charishma/Desktop/sess graph', sess.graph)
    #tf.random.set_random_seed(1234)
    sess.run(tf.initialize_all_variables())

    # Training cycle
    for epoch in range(training_epochs):
        avg_cost = 0.
        total_batch = int(total_len/batch_size)
        # Loop over all batches
        for i in range(total_batch-1):
            batch_x = X_train[i*batch_size:(i+1)*batch_size]
            batch_y = Y_train[i*batch_size:(i+1)*batch_size]
            # Run optimization op (backprop) and cost op (to get loss value)
            _, c, p = sess.run([optimizer, cost, pred], feed_dict={x: batch_x,
                                                          y: batch_y})
            # Compute average loss
            avg_cost += c / total_batch
        #save_path = saver.save(sess, "C:/Users/Charishma/Desktop/sess graph/my_model_final.ckpt")

        # sample prediction
        label_value = batch_y
        estimate = p
        err = label_value-estimate
        print ("num batch:", total_batch)

        # Display logs per epoch step
        if epoch % display_step == 0:
            print ("Epoch:", '%04d' % (epoch+1), "cost=",                 "{:.9f}".format(avg_cost))
            print ("[*]----------------------------")
            for i in range(3):
                print ("label value:", label_value[i],                     "estimated value:", estimate[i])
            print ("[*]============================")

    print ("Optimization Finished!")
    
    #writer.close()

    # Test model
    # Run optimization op (backprop) and cost op (to get loss value)
    _, c, p = sess.run([optimizer, cost, pred], feed_dict={x: X_test, y: Y_test})
    #compute cost
    print(c)
    

